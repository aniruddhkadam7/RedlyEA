const TAG = '[RedlyAgent]';

function info(...args) {
  console.log(TAG, new Date().toISOString(), ...args);
}

function error(...args) {
  console.error(TAG, new Date().toISOString(), 'ERROR', ...args);
}

module.exports = { info, error };
