const BASE_URL = process.env.REDLY_BASE_URL || 'http://localhost:3001';
const ENDPOINT = process.env.REDLY_ENDPOINT || `${BASE_URL}/api/agent/inventory`;
const COMMANDS_ENDPOINT = `${BASE_URL}/api/agent/commands`;
const COMMAND_RESULT_ENDPOINT = `${BASE_URL}/api/agent/command-result`;
const INTERVAL_MS = Number(process.env.REDLY_INTERVAL_MS) || 60_000;
const COMMAND_POLL_MS = Number(process.env.REDLY_COMMAND_POLL_MS) || 20_000;
const OSQUERY_PATH = process.env.OSQUERY_PATH || 'C:\\Program Files\\osquery\\osqueryi.exe';

module.exports = {
  BASE_URL,
  ENDPOINT,
  COMMANDS_ENDPOINT,
  COMMAND_RESULT_ENDPOINT,
  INTERVAL_MS,
  COMMAND_POLL_MS,
  OSQUERY_PATH,
};
