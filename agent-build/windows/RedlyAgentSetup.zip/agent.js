const os = require('os');
const { exec } = require('child_process');
const axios = require('axios');
const log = require('./logger');
const config = require('./config');
const { executeCommand } = require('./commands');

// ── osquery helpers ──

function runOsquery(sql) {
  return new Promise((resolve) => {
    const cmd = `"${config.OSQUERY_PATH}" --json "${sql}"`;
    exec(cmd, { timeout: 30_000 }, (err, stdout) => {
      if (err) {
        log.error(`osquery failed: ${err.message}`);
        resolve([]);
        return;
      }
      try {
        resolve(JSON.parse(stdout));
      } catch (parseErr) {
        log.error(`osquery JSON parse error: ${parseErr.message}`);
        resolve([]);
      }
    });
  });
}

async function collectApps() {
  log.info('Collecting installed applications...');
  const rows = await runOsquery('SELECT name, version, publisher FROM programs;');
  return rows.map((r) => ({
    name: r.name || 'Unknown',
    version: r.version || '',
    vendor: r.publisher || '',
  }));
}

async function collectProcesses() {
  log.info('Collecting running processes...');
  const rows = await runOsquery('SELECT name, pid, path FROM processes LIMIT 100;');
  return rows.map((r) => ({
    pid: Number(r.pid) || 0,
    name: r.name || 'Unknown',
  }));
}

// ── extended inventory collectors (run sequentially) ──

async function collectSystemInfo() {
  log.info('Collecting system info...');
  const rows = await runOsquery('SELECT hostname, computer_name, cpu_brand, physical_memory FROM system_info;');
  if (!rows.length) return undefined;
  const r = rows[0];
  return {
    hostname: r.hostname || '',
    computerName: r.computer_name || '',
    cpuBrand: r.cpu_brand || '',
    physicalMemory: r.physical_memory || '',
  };
}

async function collectOsInfo() {
  log.info('Collecting OS info...');
  const rows = await runOsquery('SELECT name, version, build, arch FROM os_version;');
  // Get last boot from uptime table
  let lastBootTime = '';
  try {
    const upRows = await runOsquery('SELECT total_seconds FROM uptime;');
    if (upRows.length) {
      const bootEpoch = Math.floor(Date.now() / 1000) - Number(upRows[0].total_seconds);
      lastBootTime = new Date(bootEpoch * 1000).toISOString();
    }
  } catch (_) { /* ignore */ }
  if (!rows.length) return { name: '', version: '', build: '', arch: '', lastBootTime };
  const r = rows[0];
  return {
    name: r.name || '',
    version: r.version || '',
    build: r.build || '',
    arch: r.arch || '',
    lastBootTime,
  };
}

async function collectNetworkInterfaces() {
  log.info('Collecting network interfaces...');
  const rows = await runOsquery('SELECT a.interface, a.address, d.mac FROM interface_addresses a LEFT JOIN interface_details d ON a.interface = d.interface;');
  return rows.map((r) => ({
    interface: r.interface || '',
    address: r.address || '',
    mac: r.mac || '',
  }));
}

async function collectListeningPorts() {
  log.info('Collecting listening ports...');
  const rows = await runOsquery('SELECT address, port, pid FROM listening_ports;');
  return rows.map((r) => ({
    address: r.address || '',
    port: Number(r.port) || 0,
    pid: Number(r.pid) || 0,
  }));
}

async function collectUsers() {
  log.info('Collecting logged-in users...');
  const rows = await runOsquery('SELECT user, tty, host, time FROM logged_in_users;');
  return rows.map((r) => ({
    user: r.user || '',
    tty: r.tty || '',
    host: r.host || '',
    time: r.time || '',
  }));
}

async function collectDisks() {
  log.info('Collecting disk drives...');
  const rows = await runOsquery('SELECT device_id, type, size, free_space FROM logical_drives;');
  return rows.map((r) => ({
    device: r.device_id || '',
    type: r.type || '',
    size: r.size || '',
    freeSpace: r.free_space || '',
  }));
}

async function collectServices() {
  log.info('Collecting Windows services...');
  const rows = await runOsquery('SELECT name, display_name, status, start_type FROM services;');
  return rows.map((r) => ({
    name: r.name || '',
    displayName: r.display_name || '',
    status: r.status || '',
    startType: r.start_type || '',
  }));
}

// ── inventory reporting cycle ──

async function collect() {
  const hostname = os.hostname();
  const platform = os.platform();

  // Core collections (parallel — lightweight)
  const [installedApps, processes] = await Promise.all([
    collectApps(),
    collectProcesses(),
  ]);

  // Extended collections (sequential to avoid overwhelming osquery)
  let systemInfo, osInfo, networkInterfaces, listeningPorts, users, disks, services;

  try { systemInfo = await collectSystemInfo(); } catch (e) { log.error(`systemInfo: ${e.message}`); }
  try { osInfo = await collectOsInfo(); } catch (e) { log.error(`osInfo: ${e.message}`); }
  try { networkInterfaces = await collectNetworkInterfaces(); } catch (e) { log.error(`networkInterfaces: ${e.message}`); }
  try { listeningPorts = await collectListeningPorts(); } catch (e) { log.error(`listeningPorts: ${e.message}`); }
  try { users = await collectUsers(); } catch (e) { log.error(`users: ${e.message}`); }
  try { disks = await collectDisks(); } catch (e) { log.error(`disks: ${e.message}`); }
  try { services = await collectServices(); } catch (e) { log.error(`services: ${e.message}`); }

  // Build process-usage snapshot (periodic sampling)
  const usageTimestamp = Date.now();
  const processUsage = processes.map((p) => ({
    name: p.name,
    pid: p.pid,
    timestamp: usageTimestamp,
  }));

  const payload = {
    hostname,
    os: platform,
    installedApps,
    processes,
    processUsage,
    systemInfo,
    osInfo,
    networkInterfaces,
    listeningPorts,
    users,
    disks,
    services,
  };

  log.info(
    `Posting inventory: ${hostname} | apps=${installedApps.length} procs=${processes.length}`,
  );

  try {
    const res = await axios.post(config.ENDPOINT, payload, {
      headers: { 'Content-Type': 'application/json' },
      timeout: 10_000,
    });
    log.info(`Inventory posted: ${JSON.stringify(res.data)}`);
  } catch (err) {
    log.error(`Inventory POST failed: ${err.message}`);
  }
}

// ── command polling cycle ──

let commandPolling = false;

async function pollCommands() {
  if (commandPolling) return; // skip if previous cycle still running
  commandPolling = true;

  const hostname = os.hostname();
  log.info('Polling for commands...');

  try {
    const res = await axios.get(config.COMMANDS_ENDPOINT, {
      params: { hostname },
      timeout: 10_000,
    });

    const commands = Array.isArray(res.data) ? res.data : [];
    if (commands.length === 0) {
      log.info('No pending commands.');
      commandPolling = false;
      return;
    }

    log.info(`Received ${commands.length} command(s).`);

    for (const cmd of commands) {
      const result = await executeCommand(cmd);
      log.info(`Command ${cmd.id} result: ${result.status}`);

      try {
        await axios.post(config.COMMAND_RESULT_ENDPOINT, result, {
          headers: { 'Content-Type': 'application/json' },
          timeout: 10_000,
        });
        log.info(`Result for ${cmd.id} reported to server.`);
      } catch (postErr) {
        log.error(`Failed to report result for ${cmd.id}: ${postErr.message}`);
      }
    }
  } catch (err) {
    log.error(`Command poll failed: ${err.message}`);
  }

  commandPolling = false;
}

// ── main ──

log.info('Agent started');
log.info(`Endpoint        : ${config.ENDPOINT}`);
log.info(`Commands        : ${config.COMMANDS_ENDPOINT}`);
log.info(`Command results : ${config.COMMAND_RESULT_ENDPOINT}`);
log.info(`Inventory every : ${config.INTERVAL_MS / 1000}s`);
log.info(`Command poll    : ${config.COMMAND_POLL_MS / 1000}s`);
log.info(`osquery         : ${config.OSQUERY_PATH}`);

// Run immediately, then repeat on intervals.
collect();
pollCommands();
setInterval(collect, config.INTERVAL_MS);
setInterval(pollCommands, config.COMMAND_POLL_MS);
