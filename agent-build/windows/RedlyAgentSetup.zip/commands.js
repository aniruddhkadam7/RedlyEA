const os = require('os');
const { exec } = require('child_process');
const log = require('./logger');

// ── Supported command handlers ──

function killProcess(payload) {
  const name = payload && payload.name;
  if (!name || typeof name !== 'string') {
    return Promise.resolve({ status: 'failed', output: 'Missing process name in payload' });
  }

  return new Promise((resolve) => {
    const cmd = `taskkill /IM "${name}" /F`;
    log.info(`Executing: ${cmd}`);
    exec(cmd, { timeout: 15_000 }, (err, stdout, stderr) => {
      const output = (stdout || '') + (stderr || '');
      if (err) {
        log.error(`kill_process failed: ${err.message}`);
        resolve({ status: 'failed', output: output.trim() || err.message });
        return;
      }
      log.info(`kill_process succeeded: ${output.trim()}`);
      resolve({ status: 'success', output: output.trim() });
    });
  });
}

const HANDLERS = {
  kill_process: killProcess,
};

/**
 * Execute a single command object { id, action, payload }.
 * Returns { hostname, commandId, status, output }.
 */
async function executeCommand(command) {
  const hostname = os.hostname();
  const { id, action, payload } = command;

  log.info(`Executing command ${id} [${action}]`);

  const handler = HANDLERS[action];
  if (!handler) {
    log.error(`Unknown action: ${action}`);
    return { hostname, commandId: id, status: 'failed', output: `Unknown action: ${action}` };
  }

  try {
    const result = await handler(payload || {});
    return { hostname, commandId: id, status: result.status, output: result.output };
  } catch (err) {
    log.error(`Command ${id} threw: ${err.message}`);
    return { hostname, commandId: id, status: 'failed', output: err.message };
  }
}

module.exports = { executeCommand };
